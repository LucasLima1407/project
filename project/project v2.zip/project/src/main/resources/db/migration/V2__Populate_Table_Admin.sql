INSERT INTO `admin` (`id`, `nome`, `login`, `senha`) VALUES
	(1, 'mardson\r\n', 'root', 'root');